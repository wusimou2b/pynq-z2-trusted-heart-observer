# External-serial-clock mode only (kGenerateSerialClk=false).
# Actual topology: MMCM/CLKOUT0 -> BUFIO -> SerialClk
#                             -> BUFR(/5) -> PixelClk
# SerialClk is NOT generated from PixelClk. Let Vivado auto-derive both
# siblings from the physical MMCM/BUFIO/BUFR. No primary-clock guess, false
# path, clock-group waiver or period reduction is introduced here.
# The power-on MMCM model and software-reprogrammed HDMI mode are separately
# reviewed; the routed design must retain one clock on each pin, ratio 5:1.
